# Chakula Dashboard Backend Integration Guide

## Files in Package
1. chakula_dashboard_ready.py - Python module with all functions
2. requirements.txt - Python dependencies
3. README.md - This guide

## Usage
1. Install dependencies:
   pip install -r requirements.txt
2. Import module in backend code:
   from chakula_dashboard_ready import load_data, prepare_sales_data, forecast_endpoint_example
3. Load CSVs and call `forecast_endpoint_example(seller_id, sales_with_price)` to get forecasts
