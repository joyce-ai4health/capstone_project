import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import joblib
import matplotlib.pyplot as plt

def load_data(food_path, sales_path, consumers_path=None, sellers_path=None):
    df_food = pd.read_csv(food_path)
    df_sales = pd.read_csv(sales_path)
    df_consumers = pd.read_csv(consumers_path) if consumers_path else None
    df_sellers = pd.read_csv(sellers_path) if sellers_path else None
    return df_food, df_sales, df_consumers, df_sellers

def prepare_sales_data(df_sales, df_food):
    df_sales['sale_date'] = pd.to_datetime(df_sales['sale_date'])
    df_sales['year'] = df_sales['sale_date'].dt.year
    df_sales['month'] = df_sales['sale_date'].dt.month
    sales_with_price = df_sales.merge(df_food[['food_id','seller_id','price']], on='food_id', how='left')
    sales_with_price['total_price'] = sales_with_price['quantity_sold'] * sales_with_price['price']
    return sales_with_price

def prepare_ml_data(sales_with_price):
    monthly_seller_revenue = sales_with_price.groupby(['year','month','seller_id'])['total_price'].sum().reset_index()
    monthly_seller_revenue['month_index'] = range(1,len(monthly_seller_revenue)+1)
    monthly_seller_ml_data = {}
    for seller_id in monthly_seller_revenue['seller_id'].unique():
        seller_data = monthly_seller_revenue[monthly_seller_revenue['seller_id']==seller_id]
        X = seller_data[['month_index']]
        y = seller_data['total_price']
        monthly_seller_ml_data[seller_id] = {'X': X, 'y': y}

    daily_seller_revenue = sales_with_price.groupby(['sale_date','seller_id'])['total_price'].sum().reset_index()
    daily_seller_revenue['day_index'] = range(1,len(daily_seller_revenue)+1)
    daily_seller_ml_data = {}
    for seller_id in daily_seller_revenue['seller_id'].unique():
        seller_data = daily_seller_revenue[daily_seller_revenue['seller_id']==seller_id]
        X = seller_data[['day_index']]
        y = seller_data['total_price']
        daily_seller_ml_data[seller_id] = {'X': X, 'y': y}

    return monthly_seller_ml_data, daily_seller_ml_data

def train_and_save_models(ml_data, index_col, filename_prefix):
    forecasts = {}
    for seller_id, data in ml_data.items():
        if len(data['X']) < 2:
            model = None
            forecast = np.array([0])
            mae = None
        else:
            X_train, X_test, y_train, y_test = train_test_split(data['X'], data['y'], test_size=0.2, shuffle=False)
            model = LinearRegression()
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            mae = mean_absolute_error(y_test, y_pred)
            last_index = data['X'][index_col].max()
            future = pd.DataFrame({index_col: [last_index + 1]})
            forecast = model.predict(future)
            joblib.dump(model, f"{filename_prefix}_seller_{seller_id}.pkl")
        forecasts[seller_id] = {'model': model, 'mae': mae, 'forecast': forecast}
    return forecasts

def forecast_all_sellers(monthly_ml_data, daily_ml_data):
    monthly_forecasts = train_and_save_models(monthly_ml_data, 'month_index', 'monthly_model')
    daily_forecasts = train_and_save_models(daily_ml_data, 'day_index', 'daily_model')
    return monthly_forecasts, daily_forecasts

def get_seller_forecast(seller_id, monthly_forecasts, daily_forecasts):
    if seller_id not in monthly_forecasts or seller_id not in daily_forecasts:
        return {'error': f"Seller {seller_id} data not available."}
    return {
        'monthly_forecast': monthly_forecasts[seller_id]['forecast'].tolist(),
        'monthly_mae': monthly_forecasts[seller_id]['mae'],
        'daily_forecast': daily_forecasts[seller_id]['forecast'].tolist(),
        'daily_mae': daily_forecasts[seller_id]['mae']
    }

def forecast_endpoint_example(seller_id, sales_with_price):
    monthly_ml_data, daily_ml_data = prepare_ml_data(sales_with_price)
    monthly_forecasts, daily_forecasts = forecast_all_sellers(monthly_ml_data, daily_ml_data)
    return get_seller_forecast(seller_id, monthly_forecasts, daily_forecasts)
